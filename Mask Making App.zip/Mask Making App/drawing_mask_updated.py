#!/usr/bin/env python3
# -*- coding: utf-8 -*-
"""
Created on Tue Feb 27 11:23:05 2024

@author: venkatesh
"""

import tkinter as tk
from tkinter import filedialog
from PIL import Image, ImageTk, ImageDraw, ImageOps
import os

class ImageMaskApp:
    
    
    def __init__(self, root):
        self.root = root
        self.root.title("Needle Masking App")
        # self.root.attributes('-fullscreen', False)
        self.root.geometry("1000x800")  # Set window size to 1024x1024 pixels
        self.root.configure(bg='white')  # Set background color to white
        self.root.iconbitmap('drawing_mask_updated.ico') 
        # Status
        self.status_label = tk.Label(self.root, text="", anchor="w", padx=10, bg='white')
        self.status_label.pack(side=tk.TOP, fill=tk.X)

        # Canvas for displaying image
        self.canvas = tk.Canvas(self.root, cursor="cross")
        self.canvas.pack(fill=tk.BOTH, expand=True)

        # Toolbar
        self.toolbar_frame = tk.Frame(self.root)
        self.toolbar_frame.pack(fill=tk.X)


        self.toolbar_frame = tk.Frame(self.root)
        self.toolbar_frame.pack(fill=tk.X)

        self.open_button = tk.Button(self.toolbar_frame, text="Open Folder", command=self.open_folder)
        self.open_button.pack(side=tk.LEFT)

        self.save_button = tk.Button(self.toolbar_frame, text="Save Mask", command=self.save_mask)
        self.save_button.pack(side=tk.LEFT)

        self.clear_button = tk.Button(self.toolbar_frame, text="Clear Mask", command=self.clear_mask)
        self.clear_button.pack(side=tk.LEFT)

        self.prev_button = tk.Button(self.toolbar_frame, text="Previous", command=self.prev_image)
        self.prev_button.pack(side=tk.LEFT)

        self.next_button = tk.Button(self.toolbar_frame, text="Next", command=self.next_image)
        self.next_button.pack(side=tk.LEFT)

        self.red_button = tk.Button(self.toolbar_frame, text="R", bg="Red",fg="white",command=lambda: self.select_color("red"))
        self.red_button.pack(side=tk.RIGHT)

        self.green_button = tk.Button(self.toolbar_frame, text="G",bg="green",fg="white", command=lambda: self.select_color("green"))
        self.green_button.pack(side=tk.RIGHT)

        self.blue_button = tk.Button(self.toolbar_frame, text="B", bg="Blue",fg="white",command=lambda: self.select_color("blue"))
        self.blue_button.pack(side=tk.RIGHT)

        # Line width selector
        self.line_width_scale = tk.Scale(self.toolbar_frame, from_=1, to=10, orient=tk.HORIZONTAL)
        self.line_width_scale.set(3)  # Default line width
        self.line_width_scale.pack(side=tk.RIGHT)
        
        self.line_width_label = tk.Label(self.toolbar_frame, padx=5, pady=10, text="Line Width:")
        self.line_width_label.pack(side=tk.RIGHT)

        self.file_label = tk.Label(self.root, text="", anchor="w", padx=10, bg='white')
        self.file_label.pack(side=tk.TOP, fill=tk.X)

        # Variables
        self.image_paths = []
        self.current_image_index = 0
        self.image = None
        self.mask = None
        self.mask_draw = None
        self.start_point = None
        self.end_point = None
        self.line_color = "red"  # Default color

    def open_folder(self):
        folder_path = filedialog.askdirectory(initialdir='/home/venkatesh/Desktop/Needle_detection/videos_with_frames/')
        if folder_path:
            self.image_paths = [os.path.join(folder_path, file) for file in os.listdir(folder_path) if file.endswith(('jpg', 'png', 'jpeg', 'gif','.tif'))]
            if self.image_paths:
                self.current_image_index = 0
                self.load_current_image()
                self.image_paths=sorted(self.image_paths)
                self.update_status()

    def load_current_image(self):
        self.image_path = self.image_paths[self.current_image_index]
        print('self.image_path',self.image_path)
        self.file_label.config(text="File: " + self.image_path)
        self.image = Image.open(self.image_path)
        self.mask = Image.new("L", self.image.size, 0)

        self.mask_draw = ImageDraw.Draw(self.mask)
        self.display_image()

    def display_image(self):
        self.canvas.delete("all")
        self.img_tk = ImageTk.PhotoImage(self.image)
        self.canvas.create_image(0, 0, anchor=tk.NW, image=self.img_tk)
        self.canvas.bind("<Button-1>", self.start_draw)
        self.canvas.bind("<ButtonRelease-1>", self.end_draw)

    def start_draw(self, event):
        self.start_point = (event.x, event.y)

    def end_draw(self, event):
        self.end_point = (event.x, event.y)
        if self.start_point and self.end_point:
            self.draw_straight_line()
            self.start_point = None
            self.end_point = None

    def draw(self, event):
        if self.start_point:
            self.canvas.delete("line")
            self.end_point = (event.x, event.y)
            self.canvas.create_line(self.start_point[0], self.start_point[1],
                                     self.end_point[0], self.end_point[1],
                                     fill="red", width=self.line_width_scale.get(), tags="line")
            self.draw_straight_line()
            self.start_point = (event.x, event.y)

    def draw_straight_line(self):
        if self.start_point and self.end_point:
            self.mask_draw.line([self.start_point, self.end_point], fill=255, width=self.line_width_scale.get(), joint="curve")
            self.canvas.create_line(self.start_point, self.end_point, fill=self.line_color, width=self.line_width_scale.get())

    def save_mask(self):
        if self.mask:
            if self.image_path:
                import matplotlib.pyplot as plt

                # colored_mask = self.mask.convert("RGB")
                # colored_mask.save(self.image_path.split(".")[0]+'_mask.tif')
                if self.image_path.endswith(('.jpg', '.png', '.jpeg', '.gif','.tif')):
                    target_file_name=self.image_path.replace('.png','_mask.png')
                    target_file_name=target_file_name.replace('.jpg','_mask.png')
                    target_file_name=target_file_name.replace('.jpeg','_mask.png')
                    target_file_name=target_file_name.replace('.gif','_mask.png')
                    target_file_name=target_file_name.replace('.tif','_mask.png')
                    
                print('target file name',target_file_name)    
                print('At save function:',self.image_path)
                self.mask.save(target_file_name)
                print('file name:',self.image_path.split(".")[0]+'_mask.png')
                print('mask saved')

                self.file_label.config(foreground="red")
                self.file_label.config(text="Saved as : " + target_file_name)

    def clear_mask(self):
        self.mask = Image.new("L", self.image.size, 0)
        self.mask_draw = ImageDraw.Draw(self.mask)
        self.canvas.delete("all")
        self.canvas.create_image(0, 0, anchor=tk.NW, image=self.img_tk)

    def select_color(self, color):
        self.line_color = color

    def next_image(self):
        if self.image_paths:
            self.current_image_index = (self.current_image_index + 1) % len(self.image_paths)
            self.load_current_image()
            self.image_path = self.image_paths[self.current_image_index]
            print(self.image_path)
            self.update_status()
            self.file_label.config(foreground="black")

    def prev_image(self):
        if self.image_paths:
            self.current_image_index = (self.current_image_index - 1) % len(self.image_paths)
            self.load_current_image()
            self.update_status()
            self.file_label.config(foreground="black")

    def update_status(self):
        image_file_name=self.image_path.replace('\\', '/').split("/")[-1]

        print('update_status:',self.image_path.split('/\\')[-1])
        num_images = len(self.image_paths)
        status_text = f"STATUS: {self.current_image_index + 1}/{num_images} "+"("+image_file_name+")"

        self.status_label.config(text=status_text)

if __name__ == "__main__":
    root = tk.Tk()
    app = ImageMaskApp(root)
    root.mainloop()
